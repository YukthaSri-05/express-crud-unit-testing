const express = require('express');
const mongoose = require('mongoose');
const path = require('path');

const app = express();

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

if (mongoose.connection.readyState === 0) {
  mongoose.connect('mongodb://localhost:27017/Devopscse');
}

app.use('/data', require('./routes/marksRoutes'));

module.exports = app;
