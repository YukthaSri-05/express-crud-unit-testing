const express = require('express');
const router = express.Router();
const Marks = require('../models/marks');


router.post('/', async (req, res) => {
  try {
    const data = new Marks(req.body); 
    await data.save();
    res.status(201).send("Inserted");
  } catch (err) {
    res.status(400).send(err.message);
  }
});


router.get('/', async (req, res) => {
  try {
    const data = await Marks.find();
    res.status(200).json(data); 
  } catch (err) {
    res.status(500).send(err.message);
  }
});




router.put('/:id', async (req, res) => {
  try {
    const numericId = parseInt(req.params.id);
    if (isNaN(numericId)) return res.status(400).send("Invalid ID");

    const updated = await Marks.findOneAndUpdate(
      { id: numericId },
      req.body,
      { new: true }
    );
    res.send(updated ? "Updated" : "Record not found");
  } catch (err) {
    res.status(400).send(err.message);
  }
});


router.delete('/:id', async (req, res) => {
  try {
    const numericId = parseInt(req.params.id);
    if (isNaN(numericId)) return res.status(400).send("Invalid ID");

    const deleted = await Marks.findOneAndDelete({ id: numericId });
    res.send(deleted ? "Deleted" : "Record not found");
  } catch (err) {
    res.status(400).send(err.message);
  }
});

module.exports = router;
